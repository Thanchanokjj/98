﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("You may use these classes in other source files for the 3rd assignment.");
    }
}