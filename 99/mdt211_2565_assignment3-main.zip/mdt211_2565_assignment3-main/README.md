# Assignment 3
This repository holds a program for the 3rd assignment of MDT 211 (2/2565) class, KMUTT.
